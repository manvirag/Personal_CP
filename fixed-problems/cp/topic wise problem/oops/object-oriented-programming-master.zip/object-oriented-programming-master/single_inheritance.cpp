#include<bits/stdc++.h>
using namespace std;
#define int long long int
const int mxN =150000;
class base{
	public:
		int x;
		
};
class derived : public base{       // can be private , protected
	public:
		int y;
};
int32_t main(){
  ios_base::sync_with_stdio(0);
   cin.tie(0); cout.tie(0);

    base temp;
    temp.x=2;




 return 0;}

